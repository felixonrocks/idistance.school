
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/lara/app/vendor/laravel/nova/resources/views/partials/meta.blade.php ENDPATH**/ ?>