<?php $__env->startSection('content'); ?>
Dashboard Content
<?php $__env->stopSection(); ?>

<?php echo $__env->make('nova::layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/lara/app/vendor/laravel/nova/resources/views/dashboard.blade.php ENDPATH**/ ?>