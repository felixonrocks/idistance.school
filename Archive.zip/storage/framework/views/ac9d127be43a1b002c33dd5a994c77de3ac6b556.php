<?php $__env->startSection('content'); ?>

    <div class="p-10 font-bold text-3xl">Widgets </div>
    <main class="bg-white min-h-screen m-10 rounded p-10">these modules are about to be uploaded..</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/lara/app/resources/views/default/widgets.blade.php ENDPATH**/ ?>