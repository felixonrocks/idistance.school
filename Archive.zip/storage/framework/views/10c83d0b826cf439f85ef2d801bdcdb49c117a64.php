<p class="mt-8 text-center text-xs text-80">
    <a href="https://nova.laravel.com" class="text-primary dim no-underline">Laravel Nova</a>
    <span class="px-1">&middot;</span>
    &copy; <?php echo e(date('Y')); ?> Laravel LLC - By Taylor Otwell, David Hemphill, and Steve Schoger.
    <span class="px-1">&middot;</span>
    v<?php echo e(\Laravel\Nova\Nova::version()); ?>

</p>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/lara/app/vendor/laravel/nova/resources/views/partials/footer.blade.php ENDPATH**/ ?>