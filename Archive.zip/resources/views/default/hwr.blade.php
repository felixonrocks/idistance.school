@extends('welcome')

@section('content')

    <div class="p-10 font-bold text-3xl">Handwriting Recognition </div>
    <main class="bg-white min-h-screen m-10 rounded p-10">HWR module is about to be uploaded..</main>
@endsection
