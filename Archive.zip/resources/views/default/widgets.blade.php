@extends('welcome')

@section('content')

    <div class="p-10 font-bold text-3xl">Widgets </div>
    <main class="bg-white min-h-screen m-10 rounded p-10">these modules are about to be uploaded..</main>
@endsection
